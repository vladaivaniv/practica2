<template>
  <footer class="text-center text-muted py-3 mt-5">
    <div class="container">
      <small>© 2025 Mi Panadería - Todos los derechos reservados</small>
    </div>
  </footer>
</template>

<script>
export default {
  name: "FooterComponent",
};
</script>

<style scoped>
/* Puedes personalizar más el footer aquí */
</style>
